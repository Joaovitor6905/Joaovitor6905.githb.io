function add() {
    performOperation((num1, num2) => num1 + num2, 'Adição');
}

function subtract() {
    performOperation((num1, num2) => num1 - num2, 'Subtração');
}

function multiply() {
    performOperation((num1, num2) => num1 * num2, 'Multiplicação');
}

function divide() {
    performOperation((num1, num2) => num2 !== 0 ? num1 / num2 : 'Erro', 'Divisão');
}

function performOperation(operation, operationName) {
    const num1 = parseFloat(document.getElementById('num1').value);
    const num2 = parseFloat(document.getElementById('num2').value);

    if (!isNaN(num1) && !isNaN(num2)) {
        const result = operation(num1, num2);
        document.getElementById('result').innerText = `${operationName}: ${result}`;
    } else {
        document.getElementById('result').innerText = 'Por favor, insira números válidos.';
    }
}
